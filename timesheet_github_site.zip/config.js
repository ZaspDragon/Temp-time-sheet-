// Paste your Google Apps Script Web App URL (ends with /exec) and set a shared secret.
window.TIMESHEET_CONFIG = {
  WEB_APP_URL: "PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE",
  SHARED_SECRET: "CHANGE_ME_TO_A_RANDOM_PASSWORD"
};
